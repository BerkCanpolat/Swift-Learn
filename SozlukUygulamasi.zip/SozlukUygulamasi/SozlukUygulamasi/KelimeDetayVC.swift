//
//  KelimeDetayVC.swift
//  SozlukUygulamasi
//
//  Created by Berk Canpolat on 5.01.2024.
//

import UIKit

class KelimeDetayVC: UIViewController {
    
    @IBOutlet weak var ingilizceLabel: UILabel!
    @IBOutlet weak var turkceLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

}
