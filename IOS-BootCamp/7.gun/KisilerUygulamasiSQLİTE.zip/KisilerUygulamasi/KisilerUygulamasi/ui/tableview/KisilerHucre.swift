//
//  KisilerHucre.swift
//  KisilerUygulamasi
//
//  Created by Berk Canpolat on 15.12.2023.
//

import UIKit

class KisilerHucre: UITableViewCell {
    
    @IBOutlet weak var labelKisiTel: UILabel!
    
    @IBOutlet weak var labelKisiAd: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
